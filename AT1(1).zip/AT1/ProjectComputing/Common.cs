﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CloudComputing
{
    class Common:CSVBL
    {
        public enum isTANORSCVs
        {
            CSVFILE,
            TANFILE
        }

        int f = -1;

        public List<CSVBL> CSVCLOUD(isTANORSCVs ofile, string filepath)
        {

            List<CSVBL> COLLETANCIONCSV = new List<CSVBL>();

            CSVBL objeTANCCSV = new CSVBL();
            if (ofile == isTANORSCVs.CSVFILE)
            {
                bool COEFFICIENTCLOUDIDDATA = false;
                string[] filedata = null;
                filedata = File.ReadAllLines(filepath);
                objeTANCCSV = new CSVBL();
                bool RUNTREFERENCEFREQUENCY = false;

                bool TASKCLOUDIDCLOUDRUNT = false;


                foreach (string CLOUD in filedata)
                {

                    if (CLOUD.IndexOf("LIMITS-TASKS") > f)
                    {

                        objeTANCCSV.LIMITSCLOUDTASKSCLOUD = CLOUD.Split(',')[1] + "," + CLOUD.Split(',')[2];

                    }
                    if (CLOUD.IndexOf("DEFAULT-LOGFILE") > f)
                    {

                        objeTANCCSV.CLOUDDEFAULTLOGFILECLOUD = CLOUD;

                    }

                    if (CLOUD.IndexOf("LIMITS-PROCESSOR-FREQUENCIES") > f)
                    {

                        objeTANCCSV.LIMITSCLOUDPROCESSORCLOUCLOUDFREQUENCYUENCIES = CLOUD.Split(',')[1] + "," + CLOUD.Split(',')[2];

                    }
                    if (CLOUD.IndexOf("LIMITS-PROCESSORS") > f)
                    {

                        objeTANCCSV.LIMITSCLOUDTASKPROCESSORS = CLOUD.Split(',')[1] + "," + CLOUD.Split(',')[2];

                    }
                    if (CLOUD.IndexOf("PROGRAM-MAXIMUM-DURATION") > f)
                    {



                        try
                        {

                            objeTANCCSV.PROGRAMCLOUDMAXIMUMCLOUDDURATION = CLOUD.Split(',')[1];
                        }
                        catch (Exception ex)
                        {
                            objeTANCCSV.PROGRAMCLOUDMAXIMUMCLOUDDURATION = CLOUD.Split('=')[1];
                        }

                    }
                    if (CLOUD.IndexOf("PROGRAM-TASKS") > f)
                    {


                        try
                        {

                            objeTANCCSV.PROGRAMCLOUDTASKSCLOUD = CLOUD.Split(',')[1];
                        }
                        catch (Exception ex)
                        {
                            objeTANCCSV.PROGRAMCLOUDTASKSCLOUD = CLOUD.Split('=')[1];
                        }

                    }
                    if (CLOUD.IndexOf("PROGRAM-PROCESSORS") > f)
                    {



                        try
                        {

                            objeTANCCSV.PROGRAMCLOUDTASKPROCESSORS = CLOUD.Split(',')[1];
                        }
                        catch (Exception ex)
                        {
                            objeTANCCSV.PROGRAMCLOUDTASKPROCESSORS = CLOUD.Split('=')[1];
                        }

                    }
                    if (CLOUD.IndexOf("RUNTIME-REFERENCE-FREQUENCY") > f)
                    {
                        try
                        {

                            objeTANCCSV.RUNTCLOUDREFERENCEFREQUENCY = CLOUD.Split(',')[1];
                        }
                        catch (Exception ex)
                        {
                            objeTANCCSV.RUNTCLOUDREFERENCEFREQUENCY = CLOUD.Split('=')[1];
                        }

                    }
                    if (CLOUD.IndexOf("TASK-ID,RUNTIME") > f)
                    {
                        TASKCLOUDIDCLOUDRUNT = true;



                    }

                    if (CLOUD.IndexOf("PROCESSOR-ID,FREQUENCY") > f)
                    {
                        TASKCLOUDIDCLOUDRUNT = false;
                        RUNTREFERENCEFREQUENCY = true;




                    }
                    if (CLOUD.IndexOf("COEFFICIENT-ID,VALUE") > f)
                    {
                        COEFFICIENTCLOUDIDDATA = true;
                        TASKCLOUDIDCLOUDRUNT = false;
                        RUNTREFERENCEFREQUENCY = false;



                    }

                    if (TASKCLOUDIDCLOUDRUNT)
                    {

                        try
                        {
                            objeTANCCSV = CoefficeintProceess(CLOUD, objeTANCCSV);
                        }
                        catch (Exception exp)
                        {

                        }

                    }

                    if (RUNTREFERENCEFREQUENCY)
                    {
                        try
                        {
                            objeTANCCSV = COEFFICIENTIDDATA_PROCESS(CLOUD, objeTANCCSV);
                        }
                        catch (Exception exp)
                        {

                        }
                    }
                    if (COEFFICIENTCLOUDIDDATA)
                    {

                        try
                        {
                            objeTANCCSV = COEFFICIENTIDDATA_PROCESSCLOUD(CLOUD, objeTANCCSV);
                        }
                        catch (Exception exp)
                        {

                        }
                    }
                }
                COLLETANCIONCSV.Add(objeTANCCSV);

            }
            return COLLETANCIONCSV;
        }
        CSVBL COEFFICIENTIDDATA_PROCESSCLOUD(string CLOUD, CSVBL objeTANCCSV)
        {
            string[] DATAs = CLOUD.Split(',');

            if (Convert.ToInt16(DATAs[0]) < 0 || Convert.ToInt16(DATAs[1]) < 0)
            {
                objeTANCCSV.COEFFICIENTCLOUDIDDATA.Add(CLOUD);
            }

            {
                string[] vs = CLOUD.Split('-');


                if (vs.Length == 1)
                {

                    if (CLOUD.IndexOf("//") == f)
                    {
                        if (CLOUD != "")
                        {
                            objeTANCCSV.COEFFICIENTCLOUDIDDATA.Add(CLOUD);

                        }
                    }
                }
            }
            return objeTANCCSV;
        }
        CSVBL CoefficeintProceess(string CLOUD, CSVBL objeTANCCSV)
        {
            string[] DATAs = CLOUD.Split(',');
            if (Convert.ToInt16(DATAs[0]) < 0 || Convert.ToInt16(DATAs[1]) < 0)
            {
                objeTANCCSV.COEFFICIENTCLOUDIDDATA.Add(CLOUD);
            }

            {
                string[] sp = CLOUD.Split('-');
                if (sp.Length == 1)
                {

                    if (CLOUD.IndexOf("//") == f)
                    {
                        if (CLOUD != "")
                        {
                            objeTANCCSV.TASKCLOUDIDCLOUDRUNT.Add(CLOUD);
                        }
                    }
                }

            }
            return objeTANCCSV;
        }

        CSVBL COEFFICIENTIDDATA_PROCESS(string CLOUD, CSVBL objeTANCCSV)
        {
            string[] DATAs = CLOUD.Split(',');

            if (Convert.ToInt16(DATAs[0]) < 0 || Convert.ToInt16(DATAs[1]) < 0)
            {
                objeTANCCSV.COEFFICIENTCLOUDIDDATA.Add(CLOUD);
            }

            {
                string[] sp = CLOUD.Split('-');
                if (sp.Length == 1)
                {

                    if (CLOUD.IndexOf("//") == f)
                    {
                        if (CLOUD != "")
                        {
                            objeTANCCSV.RUNTREFERENCEFREQUENCY.Add(CLOUD);
                        }
                    }
                }
            }
            return objeTANCCSV;
        }
        //=====================================================================

        public List<TANBL> TANCLOUD(isTANORSCVs ofile, string filepath)
        {
            List<TANBL> COLLETANCIONTAN = new List<TANBL>();

            int f = -1;
            TANBL objectTAN = new TANBL();
            if (ofile == isTANORSCVs.TANFILE)
            {
                string[] AllFiles = File.ReadAllLines(filepath);
                objectTAN = new TANBL();
                List<string> vALLOCATEDTASKP;
                int cont = 0;
                foreach (string CLOUD in AllFiles)
                {
                    if (CLOUD.IndexOf("TASKS") > f)
                    {
                        objectTAN.CLOUDTASKS = CLOUD.Split(',')[1];

                    }
                    if (CLOUD.IndexOf("CONFIGURATION") > f)
                    {
                        objectTAN.CLOUDCONFIG = CLOUD.Split(',')[1];

                    }
                    if (CLOUD.IndexOf("CONFIG-FILE") > f)
                    {
                        objectTAN.CLOUDCONFIG = CLOUD.Split(',')[1];

                    }
                    if (CLOUD.IndexOf("ALLOCATIONS") > f)
                    {
                        objectTAN.ALLOCATIONSCLOUD = CLOUD.Split(',')[1].ToString();

                    }
                    if (CLOUD.IndexOf("TASKPROCESSORS") > f)
                    {
                        objectTAN.ALLOCATIONSCLOUD = CLOUD.Split(',')[1];

                    }
                    if (CLOUD.IndexOf("ALLOCATION-ID") > f)
                    {
                        cont = 0; objectTAN.CLOUDALLOCATIONIDCLOUD = Convert.ToInt16(CLOUD.Split(',')[1]);

                        vALLOCATEDTASKP = new List<string>();
                    }
                    else
                    {
                        if (CLOUD.Split(',').Length >= 5)
                        {
                            objectTAN.ALLOCATEDTASK.Add(CLOUD);
                            if (cont == 2) { COLLETANCIONTAN.Add(objectTAN); }
                            cont++;

                        }
                    }
                }

            }
            return COLLETANCIONTAN;

        }
    }
}
