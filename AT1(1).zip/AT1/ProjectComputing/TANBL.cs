﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;

namespace CloudComputing
{
    class TANBL
    {
        List<string> CLOUDALLOCATEDTASK = new List<string>();
        
        string CLOUDALLOCATIONS;
        string _CLOUDTASKS;
        string CLOUDPROCESSORS;
        string CLOUDCONFIGCLOUD;

        int CLOUDALLOCATIONID;
        public List<string> ALLOCATEDTASK { get { return CLOUDALLOCATEDTASK; } set { CLOUDALLOCATEDTASK = value; } }
        public string ALLOCATIONSCLOUD {get { return CLOUDALLOCATIONS; }set { CLOUDALLOCATIONS = value; }}
        public int CLOUDALLOCATIONIDCLOUD { get { return CLOUDALLOCATIONID; } set { CLOUDALLOCATIONID = value; } }
        public string CLOUDCONFIG {get { return CLOUDCONFIGCLOUD; }set { CLOUDCONFIGCLOUD = value; }}
        public string PROCESSORS {get { return CLOUDPROCESSORS; } set { CLOUDPROCESSORS = value; }}

        public string CLOUDTASKS { get { return _CLOUDTASKS; } set { _CLOUDTASKS = value; } }


    }
    
}
