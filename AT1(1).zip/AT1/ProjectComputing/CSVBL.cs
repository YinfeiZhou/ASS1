﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;

namespace CloudComputing
{
    class CSVBL : TANBL
    {
        string COLLETANCIONPROGRAMTASKPROCESSORS;
        string CLOUDPROGRAMMTASKSCLOUD;
        string CLOUDRUNTREFERENCEFREQUENCY;
        string LIMITSTASKPROCESSORS;
        string LIMITSPROCESSORFREQUENCIES;
        string CLOUDDEFAULTLOGFILE;
        string LIMITSTASKSCLOUD;
        string CLOUDPROGRAMMAXIMUMDURATION;


        public string RUNTCLOUDREFERENCEFREQUENCY { get { return CLOUDRUNTREFERENCEFREQUENCY; } set { CLOUDRUNTREFERENCEFREQUENCY = value; } }

        public string PROGRAMCLOUDTASKPROCESSORS { get { return COLLETANCIONPROGRAMTASKPROCESSORS; } set { COLLETANCIONPROGRAMTASKPROCESSORS = value; } }

        public string PROGRAMCLOUDTASKSCLOUD { get { return CLOUDPROGRAMMTASKSCLOUD; } set { CLOUDPROGRAMMTASKSCLOUD = value; } }

        public string LIMITSCLOUDPROCESSORCLOUCLOUDFREQUENCYUENCIES { get { return LIMITSPROCESSORFREQUENCIES; } set { LIMITSPROCESSORFREQUENCIES = value; } }

        public string LIMITSCLOUDTASKSCLOUD{get { return LIMITSTASKSCLOUD; } set { LIMITSTASKSCLOUD = value; } }
      
        public string LIMITSCLOUDTASKPROCESSORS { get { return LIMITSTASKPROCESSORS; } set { LIMITSTASKPROCESSORS = value; } }
    
        public string PROGRAMCLOUDMAXIMUMCLOUDDURATION { get { return CLOUDPROGRAMMAXIMUMDURATION; } set { CLOUDPROGRAMMAXIMUMDURATION = value; } }

        public string CLOUDDEFAULTLOGFILECLOUD { get { return CLOUDDEFAULTLOGFILE; } set { CLOUDDEFAULTLOGFILE = value; } }


     




        List<string> COLLETANCIONPROCESSORICLOUDFREQUENCYUENCY = new List<string>();
        List<string> COLLETANCIONCOEFICENTIENTIDDATA = new List<string>();
        List<string> COLLETANCIONTASKIDRUNT = new List<string>();



        public List<string> COEFFICIENTCLOUDIDDATA { get { return COLLETANCIONCOEFICENTIENTIDDATA; } set { COLLETANCIONCOEFICENTIENTIDDATA = value; } }
        public List<string> RUNTREFERENCEFREQUENCY { get { return COLLETANCIONPROCESSORICLOUDFREQUENCYUENCY; } set { COLLETANCIONPROCESSORICLOUDFREQUENCYUENCY = value; } }
        public List<string> TASKCLOUDIDCLOUDRUNT { get { return COLLETANCIONTASKIDRUNT; } set { COLLETANCIONTASKIDRUNT = value; } }

       

       

    }
}
