﻿using System;

using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CloudComputing
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the appliContation.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new RunComputing());
        }
    }
}
