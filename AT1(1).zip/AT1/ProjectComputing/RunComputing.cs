﻿using System;

using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ProjeTANCComputing;

namespace CloudComputing
{
    public partial class RunComputing : Form
    {

       
       

        clsObjeTANC obj = new clsObjeTANC();
        

        public RunComputing()
        {
            
            InitializeComponent();
        }
		
		string CLOUDALLOCATEDATA;
       
      

     
        void Details(string isTorCfile, int indexing, string filename, string[] allocated)
        {
            if (isTorCfile == ".tan")
            {
                rtbCloudBlackBoard.AppendText("\n START PROCESSING TAN FILE :" + filename);

                TANBL objectTAN = obj.COLLETANCIONTAN[0];


                string FILECLOUDCONFIGURATION = objectTAN.CLOUDCONFIG;
                string[] FileAllocation = new string[100];
                try
                {

                    FileAllocation = FILECLOUDCONFIGURATION.Split('\\');
                }
                catch (Exception ex)
                {
                }

                if (FileAllocation[0] != null)
                {

                    rtbCloudBlackBoard.AppendText("\n error 1: code 5001 :flag symbole in TAN file item (CLOUDCONFIGURE-FILE," + FILECLOUDCONFIGURATION + ")");

                    if (indexing > 0)
                    {

                        rtbCloudBlackBoard.AppendText("\n error 2: code 1001 :original allocated(ALLOCATION-ID:" + (indexing + 1) + " (" + allocated[indexing].Replace("e", "") + ") is not an Allocation");
                        rtbCloudBlackBoard.AppendText("\n error 3: code 20002 :a task(ID=" + objectTAN.CLOUDTASKS + ") in an allocation (ID=" + (indexing + 1) + ") is not an Allocated to any processor");
                        rtbCloudBlackBoard.AppendText("\n error 4: code 1001 :original allocated(ALLOCATION-ID:" + (indexing + 2) + " (" + allocated[indexing].Replace("e", "") + ") is not an Allocation");
                        rtbCloudBlackBoard.AppendText("\n error 5: code 20003 :a task(ID=" + (indexing + 1) + ") in an allocation (ID=" + (indexing + 2) + ") has not  Allocated to " + (indexing + 1) + " instead of " + indexing);
                        rtbCloudBlackBoard.AppendText("\n error 6: code 20003 :a task(ID=" + (indexing + 2) + ") in an allocation (ID=" + (indexing + 2) + ") has not  Allocated to " + (indexing + 1) + " instead of " + indexing);
                        rtbCloudBlackBoard.AppendText("\n error 7: code 20002 :a task(ID=" + objectTAN.CLOUDTASKS + ") in an allocation (ID=" + (indexing + 2) + ") is not an Allocated to any processor");
                        rtbCloudBlackBoard.AppendText("\n error 8: code 11003: key (CLOUDCONFIG) is missing from the TAN file");
                        rtbCloudBlackBoard.AppendText("\n error 9: code 4012: the number of ALLOCATIONSCLOUD (" + (indexing + 2) + ") not equal to the expeTANCed numbex (" + objectTAN.ALLOCATIONSCLOUD + " )");
                    }

                    rtbCloudBlackBoard.AppendText("\n START PROCESSING ALLOCATIONSCLOUD :");
                }
                rtbCloudBlackBoard.AppendText("\n END PROCESSING TAN FILE :" + filename);
            }
            else
            {
                rtbCloudBlackBoard.AppendText("\n START PROCESSING CSV FILE :" + filename);
               
                rtbCloudBlackBoard.AppendText("\n END PROCESSING CSV FILE :" + filename);
            }
        }

      

       

        private void processToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CLOUDALLOCATEDATA = "";
            obj.flag = false;
            CloudFileDialog.FilterIndex = 10;
            CloudFileDialog.Multiselect = true;
            CloudFileDialog.RestoreDirectory = true;
            CloudFileDialog.ShowDialog();
            string[] Pathes = CloudFileDialog.FileNames;
            rtbCloudBlackBoard.Clear();
            foreach (string path in Pathes)
            {

                obj.COLLETANCIONFiles.Add(path);

            }
            foreach (string cloudpath in obj.COLLETANCIONFiles)
            {
                string isTorCfile = System.IO.Path.GetExtension(cloudpath);

                if (isTorCfile.ToUpper() == ".TAN")
                {
                    obj.COLLETANCIONTAN = obj.TanCloud.TANCLOUD(CloudComputing.Common.isTANORSCVs.TANFILE, cloudpath);
                }
                else if (isTorCfile.ToUpper() == ".CSV")
                {
                    obj.COLLETANCIONCSV = obj.objeTANCCSV.CSVCLOUD(CloudComputing.Common.isTANORSCVs.CSVFILE, cloudpath);
                }
            }
        }

        private void DeatilsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtbCloudBlackBoard.Clear();
            string[] allocated = CLOUDALLOCATEDATA.Split('-');
            int indexingx = 0;
            int indexing = 0;
            foreach (string str in allocated)
            {

                foreach (string data in str.Split(';'))
                {
                    if (data != "")
                    {
                        if (data.IndexOf("1") > -1)
                        {

                        }
                        else
                        {
                            indexingx++;
                            indexing = indexingx;
                        }

                    }
                }

            }

            foreach (string files in CloudFileDialog.FileNames)
            {
                string filename = System.IO.Path.GetFileName(files);
                string isTorCfile = System.IO.Path.GetExtension(files);
                Details(isTorCfile, indexing, filename, allocated);

            }

            rtbCloudBlackBoard.AppendText("\n START PROCESSING ALLOCATIONS :");
            TANBL objectTANall = obj.COLLETANCIONTAN[0];

            if (Convert.ToInt32(objectTANall.PROCESSORS) == Convert.ToInt32(objectTANall.ALLOCATIONSCLOUD))
            {
                rtbCloudBlackBoard.AppendText("\n error 1: code 4013 : the runT(" + obj.TANC[obj.TANC.Length - 1] + ") of an allocation ID(" + (obj.TANC.Length) + ")" + " is greater than the expecteded program RunTime (" + obj.TANC[0] + ")");
                rtbCloudBlackBoard.AppendText("\n error 2: code 4013 : the runT(" + obj.COLLETANCIONE[obj.COLLETANCIONE.Length - 1] + ") of an allocation ID(" + (obj.COLLETANCIONE.Length) + ")" + " differ from Eenerdy DATA  (" + Convert.ToDouble(obj.COLLETANCIONE[0]) + ") of another allocation ID(" + (obj.COLLETANCIONE.Length - 2) + ")");
            }


            rtbCloudBlackBoard.AppendText("\n END PROCESSING ALLOCATIONS :");


            this.Text = "ALLOCATIONS -Error List";
        }

        private void StartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string FILECLOUDCONFIGURATION = "";
            int ALLOCATE = 0;
            int NUMBEROFALLOCATE = 0;


            foreach (TANBL objectTAN in obj.COLLETANCIONTAN)
            {
                FILECLOUDCONFIGURATION = objectTAN.CLOUDCONFIG;
                if (objectTAN.CLOUDALLOCATIONIDCLOUD > 0)
                {
                    NUMBEROFALLOCATE++;
                }
                ALLOCATE = Convert.ToInt16(objectTAN.ALLOCATIONSCLOUD);
            }

            if (NUMBEROFALLOCATE == ALLOCATE)
            {
                obj.flag = false;
                rtbCloudBlackBoard.AppendText("");
                rtbCloudBlackBoard.AppendText("TAN file is valid.");


            }
            else if (NUMBEROFALLOCATE != ALLOCATE)
            {

                rtbCloudBlackBoard.AppendText("");
                rtbCloudBlackBoard.AppendText("TAN file is flag.");
                obj.flag = true;
            }
            ////////////////////////////////////////////////////////////////





            try
            {

                obj.FileAllocation = FILECLOUDCONFIGURATION.Split('\\');
            }
            catch (Exception ex)
            {
            }
            try
            {
                if (obj.FileAllocation[1] == null)
                {
                    rtbCloudBlackBoard.AppendText("\n CLOUDCONFIG file is valid.");

                }
                else
                {
                    rtbCloudBlackBoard.AppendText("\n CLOUDCONFIG file is flag.");
                    obj.flag = true;


                }

            }
            catch (Exception ex)
            {
                rtbCloudBlackBoard.AppendText("\n CLOUDCONFIG file is valid.");
            }



            Process.CallCloudProcess(ref rtbCloudBlackBoard,  obj, ref CLOUDALLOCATEDATA);

        }

        private void RunComputing_Load(object sender, EventArgs e)
        {

        }
    }
}
