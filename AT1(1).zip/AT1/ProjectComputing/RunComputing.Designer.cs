﻿namespace CloudComputing
{
    partial class RunComputing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DeatilsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CloudMenuOption = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.processToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.validationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.StartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rtbCloudBlackBoard = new System.Windows.Forms.RichTextBox();
            this.CloudFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.CloudMenuOption.SuspendLayout();
            this.SuspendLayout();
            // 
            // DeatilsToolStripMenuItem
            // 
            this.DeatilsToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.DeatilsToolStripMenuItem.Name = "DeatilsToolStripMenuItem";
            this.DeatilsToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.DeatilsToolStripMenuItem.Text = "Details";
            this.DeatilsToolStripMenuItem.Click += new System.EventHandler(this.DeatilsToolStripMenuItem_Click);
            // 
            // CloudMenuOption
            // 
            this.CloudMenuOption.BackColor = System.Drawing.Color.Transparent;
            this.CloudMenuOption.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.CloudMenuOption.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.validationToolStripMenuItem,
            this.viewToolStripMenuItem});
            this.CloudMenuOption.Location = new System.Drawing.Point(0, 0);
            this.CloudMenuOption.Name = "CloudMenuOption";
            this.CloudMenuOption.Size = new System.Drawing.Size(575, 24);
            this.CloudMenuOption.TabIndex = 2;
            this.CloudMenuOption.Text = "CloudMenuOption";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.processToolStripMenuItem});
            this.fileToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // processToolStripMenuItem
            // 
            this.processToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.processToolStripMenuItem.Name = "processToolStripMenuItem";
            this.processToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.processToolStripMenuItem.Text = "Open File";
            this.processToolStripMenuItem.Click += new System.EventHandler(this.processToolStripMenuItem_Click);
            // 
            // validationToolStripMenuItem
            // 
            this.validationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StartToolStripMenuItem});
            this.validationToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.validationToolStripMenuItem.Name = "validationToolStripMenuItem";
            this.validationToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.validationToolStripMenuItem.Text = "Validation";
            // 
            // StartToolStripMenuItem
            // 
            this.StartToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.StartToolStripMenuItem.Name = "StartToolStripMenuItem";
            this.StartToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.StartToolStripMenuItem.Text = "Start";
            this.StartToolStripMenuItem.Click += new System.EventHandler(this.StartToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.DeatilsToolStripMenuItem});
            this.viewToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // rtbCloudBlackBoard
            // 
            this.rtbCloudBlackBoard.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.rtbCloudBlackBoard.ForeColor = System.Drawing.Color.Lime;
            this.rtbCloudBlackBoard.Location = new System.Drawing.Point(12, 27);
            this.rtbCloudBlackBoard.Name = "rtbCloudBlackBoard";
            this.rtbCloudBlackBoard.Size = new System.Drawing.Size(551, 688);
            this.rtbCloudBlackBoard.TabIndex = 3;
            this.rtbCloudBlackBoard.Text = "";
            // 
            // CloudFileDialog
            // 
            this.CloudFileDialog.FileName = "CloudFileDialog";
            // 
            // RunComputing
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(575, 733);
            this.Controls.Add(this.CloudMenuOption);
            this.Controls.Add(this.rtbCloudBlackBoard);
            this.Name = "RunComputing";
            this.Text = "AssessmentTask1";
            this.Load += new System.EventHandler(this.RunComputing_Load);
            this.CloudMenuOption.ResumeLayout(false);
            this.CloudMenuOption.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem DeatilsToolStripMenuItem;
        private System.Windows.Forms.MenuStrip CloudMenuOption;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem processToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem validationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem StartToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.RichTextBox rtbCloudBlackBoard;
        private System.Windows.Forms.OpenFileDialog CloudFileDialog;
    }
}