﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CloudComputing
{
    class clsObjeTANC
    {
        public double CLOUDFREQUENCY = 3.3;
        public double timevalue = 2.5;
     
       
        
        public string[] FileAllocation = new string[50];
        public double[] CLOUDFREQUENCYuency = new double[3];
        public double[] TANC = new double[3];
        public double[] COLLETANCIONE = new double[3];

        public bool flag = false;



        public Common TanCloud = new Common();
        public TANBL objectTAN = new TANBL();
        public Common objeTANCCSV = new Common();

        public List<CSVBL> COLLETANCIONCSV = new List<CSVBL>();
        public List<TANBL> COLLETANCIONTAN = new List<TANBL>();
        public List<string> COLLETANCIONFiles = new List<string>();
        public clsObjeTANC()
       {
           CLOUDFREQUENCYuency[2] = 3.91;
           CLOUDFREQUENCYuency[1] = 4.239;
           CLOUDFREQUENCYuency[0] = 4.239;

           TANC[2] = 9.09;
           TANC[0] = 8;
           TANC[1] = 8;
          
       }
    }
}
