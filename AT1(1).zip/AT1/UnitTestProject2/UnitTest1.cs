﻿using System;
using CloudComputing;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject2
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]

        double EnergyCalcualtion(CSVBL objeTANCCSV, clsObjeTANC obj)
        {


            double DATA3 =3;

            double DATA2 = 4;
            double DATA1 = 5;

            return (DATA1 * (obj.CLOUDFREQUENCY * obj.CLOUDFREQUENCY) + DATA2 * obj.CLOUDFREQUENCY + DATA3) * obj.timevalue;
        }

        [TestMethod]
        public void TestMethod1()
        {
            CSVBL objeTANCCSV = new CSVBL();
            clsObjeTANC obj = new clsObjeTANC();
            try
            {
                objeTANCCSV.COEFFICIENTCLOUDIDDATA[0] = "3";
                objeTANCCSV.COEFFICIENTCLOUDIDDATA[1] = "4";
                objeTANCCSV.COEFFICIENTCLOUDIDDATA[2] = "5";

                obj.CLOUDFREQUENCY = 5;
                obj.timevalue = 1.28;
            }
            catch (Exception ex) { }
            EnergyCalcualtion(objeTANCCSV, obj);
        }
    }
}
