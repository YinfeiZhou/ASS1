﻿using System;

using System.Linq;
using System.Text;

using CloudComputing;

namespace ProjeTANCComputing
{
    class Process : CSVBL
    {
       public  static void CallCloudProcess( clsObjeTANC obj, ref string CLOUDALLOCATEDATA)
        {
            TANBL objTANBL = obj.COLLETANCIONTAN[0];
            int count = 0;
            int itemcount = 0;
            int counter = 0;
            int row=0;
          
            counter = 1;

            int acount = objTANBL.ALLOCATEDTASK.Count / Convert.ToInt16(objTANBL.ALLOCATIONSCLOUD);
            itemcount = acount;

           

            if (Convert.ToInt32(objTANBL.PROCESSORS) == Convert.ToInt32(objTANBL.ALLOCATIONSCLOUD))
            {
                CSVBL objectCSV = obj.COLLETANCIONCSV[0];
                int ind = 0;
                int l = 0;
             
              



                for (int p = 0; p <= Convert.ToInt32(obj.COLLETANCIONTAN[0].ALLOCATIONSCLOUD) - 1; p++)
                {
                    double DATA1 = Convert.ToDouble((objectCSV.COEFFICIENTCLOUDIDDATA[2].Split(',')[1]));
                    double DATA2 = Convert.ToDouble((objectCSV.COEFFICIENTCLOUDIDDATA[1].Split(',')[1]));
                    double DATA3 = Convert.ToDouble((objectCSV.COEFFICIENTCLOUDIDDATA[0].Split(',')[1]));

                    obj.COLLETANCIONE[ind] = (DATA1 * (obj.CLOUDFREQUENCYuency[ind] * obj.CLOUDFREQUENCYuency[ind]) + DATA2 * obj.CLOUDFREQUENCYuency[ind] + DATA3) * obj.TANC[ind];
                    ind++;
                }



             




                foreach (TANBL objectTAN in obj.COLLETANCIONTAN)
                {


                    if (Convert.ToInt16(objectTAN.ALLOCATIONSCLOUD) >= counter)
                    {
                        string outputs = "\n  Allocation ID:=" + counter + ",Time:=" + obj.TANC[l] + ",Energy:=" + obj.COLLETANCIONE[l];
                       
                        for (count = row; count <= itemcount - 1; count++)
                        {
                            CLOUDALLOCATEDATA = CLOUDALLOCATEDATA + objectTAN.ALLOCATEDTASK[count] + ";";
                          
                        }
                        row = count;
                        l++;
                        CLOUDALLOCATEDATA = CLOUDALLOCATEDATA + "-";
                        itemcount = itemcount + acount;
                        counter = counter + 1;
                    }
                }

            }
           

            else if (obj.flag == false)
            {


                double Eng = 0;
                foreach (CSVBL objectCSV in obj.COLLETANCIONCSV)
                {
                    Eng = EnergyCalcualtion(objectCSV,obj);
                }

              
                foreach (TANBL objectTAN in obj.COLLETANCIONTAN)
                {


                    if (Convert.ToInt16(objectTAN.ALLOCATIONSCLOUD) >= counter)
                    {
                       String data=("\n  Allocation ID:=" + counter + ",Time:=" + obj.timevalue + ",Energy:=" + Eng);

                        for (count = row; count <= itemcount - 1; count++)
                        {
                            CLOUDALLOCATEDATA = CLOUDALLOCATEDATA + objectTAN.ALLOCATEDTASK[count] + ";";
                            data=("\n \n " + objectTAN.ALLOCATEDTASK[count]);
                        }
                        row = count;
                        CLOUDALLOCATEDATA = CLOUDALLOCATEDATA + "-";
                        itemcount = itemcount + acount;
                        counter = counter + 1;
                    }
                }
            }
            else if (obj.flag)
            {
                acount = 3;
                itemcount = 3;
               
                foreach (TANBL objectTAN in obj.COLLETANCIONTAN)
                {


                    if (Convert.ToInt16(objectTAN.ALLOCATEDTASK.Count) >= counter)
                    {
                        string data=("\n  Allocation ID=" + counter + ",T=inValid" + ",E=Invalid");
                        for (count = row; count <= itemcount - 1; count++)
                        {
                            data=("\n \n " + objectTAN.ALLOCATEDTASK[count]);
                            CLOUDALLOCATEDATA = CLOUDALLOCATEDATA + objectTAN.ALLOCATEDTASK[count] + ";";
                        }
                        row = count;
                        itemcount = itemcount + acount;
                        counter = counter + 1;
                        CLOUDALLOCATEDATA = CLOUDALLOCATEDATA + "-";
                    }
                }

            }

        }

     static   double EnergyCalcualtion(CSVBL objeTANCCSV, clsObjeTANC obj)
        {


            double DATA3 = Convert.ToDouble((objeTANCCSV.COEFFICIENTCLOUDIDDATA[0].Split(',')[1]));

            double DATA2 = Convert.ToDouble((objeTANCCSV.COEFFICIENTCLOUDIDDATA[1].Split(',')[1]));
            double DATA1 = Convert.ToDouble((objeTANCCSV.COEFFICIENTCLOUDIDDATA[2].Split(',')[1]));

            return (DATA1 * (obj.CLOUDFREQUENCY * obj.CLOUDFREQUENCY) + DATA2 * obj.CLOUDFREQUENCY + DATA3) * obj.timevalue;
        }

    }
}
